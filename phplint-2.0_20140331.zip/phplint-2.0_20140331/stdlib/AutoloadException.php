<?php

/*. require_module 'standard'; .*/

/**
	Exception thrown if class autoloading failed to load a class.
	@author Umberto Salsi <salsi@icosaedro.it>
	@version $Date: 2012/01/22 19:25:15 $
*/
/*. unchecked .*/ class AutoloadException extends Exception {}
