<?php

namespace it\icosaedro\lint;


/**
 * 
 * @author Umberto Salsi <salsi@icosaedro.it>
 * @version $Date: 2014/01/12 03:27:44 $
 */
abstract class Enum {
	
//	private static /*. Enum[int] .*/ $consts;
//	
//	public /*. void .*/ function __construct(){
//		Enum::$consts = /*. (Enum[int]) .*/ array();
//	}
//	
//	
//	public /*. Enum .*/ function add(/*. string .*/ $name){
//		
//	}
	
}
