<?php
/** Verisign Payflow Pro Functions.

See: {@link http://www.php.net/manual/en/ref.pfpro.php}
@package pfpro
*/



/*. string.*/ function pfpro_version(){}
/*. bool  .*/ function pfpro_init(){}
/*. bool  .*/ function pfpro_cleanup(){}
/*. string.*/ function pfpro_process_raw(/*. string .*/ $parmlist /*., args .*/){}
/*. array .*/ function pfpro_process(/*. array .*/ $parmlist /*., args .*/){}
