<?php
/**
filePro Functions.

This module is available from the PECL project.
<p>

See: {@link http://www.php.net/manual/en/ref.filepro.php}
@package filepro
*/



/*. bool  .*/ function filepro(/*. string .*/ $directory){}
/*. int   .*/ function filepro_rowcount(){}
/*. string.*/ function filepro_fieldname(/*. int .*/ $fieldnumber){}
/*. string.*/ function filepro_fieldtype(/*. int .*/ $field_number){}
/*. int   .*/ function filepro_fieldwidth(/*. int .*/ $field_number){}
/*. int   .*/ function filepro_fieldcount(){}
/*. string.*/ function filepro_retrieve(/*. int .*/ $row_number, /*. int .*/ $field_number){}
