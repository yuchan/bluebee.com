<?php
/**
COM and .Net (Windows).

<b>WARNING.</b> This module is mostly incomplete.
<p>

See: {@link http://www.php.net/manual/en/ref.com.php}
@package com
*/


/*. object .*/ function com_get_active_object(/*. string .*/ $progid /*., args .*/){}
/*. string .*/ function com_create_guid(){}
/*. bool .*/ function com_event_sink(/*. object .*/ $comobject, /*. object .*/ $sinkobject /*., args .*/){}
/*. bool .*/ function com_print_typeinfo(/*. args .*/){}
/*. bool .*/ function com_message_pump( /*. args .*/){}
/*. bool .*/ function com_load_typelib(/*. string .*/ $typelib_name /*., args .*/){}
