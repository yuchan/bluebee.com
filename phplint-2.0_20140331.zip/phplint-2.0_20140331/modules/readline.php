<?php
/** GNU Readline.

See: {@link http://www.php.net/manual/en/ref.readline.php}
@package readline
*/



/*. string .*/ function readline( /*. args .*/){}
/*. mixed .*/ function readline_info( /*. args .*/){}
/*. bool .*/ function readline_add_history( /*. args .*/){}
/*. bool .*/ function readline_clear_history(){}
/*. array .*/ function readline_list_history(){}
/*. bool .*/ function readline_read_history( /*. args .*/){}
/*. bool .*/ function readline_write_history( /*. args .*/){}
/*. bool .*/ function readline_completion_function(/*. mixed .*/ $funcname){}
