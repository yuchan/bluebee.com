<?php
/**
Character Type Functions.

See: {@link http://www.php.net/manual/en/ref.ctype.php}
@package ctype
*/


/*. bool .*/ function ctype_alnum(/*. mixed .*/ $c){}
/*. bool .*/ function ctype_alpha(/*. mixed .*/ $c){}
/*. bool .*/ function ctype_digit(/*. mixed .*/ $c){}
/*. bool .*/ function ctype_lower(/*. mixed .*/ $c){}
/*. bool .*/ function ctype_graph(/*. mixed .*/ $c){}
/*. bool .*/ function ctype_print(/*. mixed .*/ $c){}
/*. bool .*/ function ctype_punct(/*. mixed .*/ $c){}
/*. bool .*/ function ctype_space(/*. mixed .*/ $c){}
/*. bool .*/ function ctype_upper(/*. mixed .*/ $c){}
/*. bool .*/ function ctype_xdigit(/*. mixed .*/ $c){}
