<?php
/** NSAPI-specific Functions.

See: {@link http://www.php.net/manual/en/ref.nsapi.php}
@package nsapi
*/



/*. bool .*/ function nsapi_virtual(/*. string .*/ $uri){}
/*. array[string]string .*/ function nsapi_request_headers(){}
/*. array[string]string .*/ function nsapi_response_headers(){}
