<?php
/** GNU Recode Functions.

See: {@link http://www.php.net/manual/en/ref.recode.php}
@package recode
*/


/*. string.*/ function recode_string(/*. string .*/ $request, /*. string .*/ $str){}
/*. bool  .*/ function recode_file(/*. string .*/ $request, /*. resource .*/ $input, /*. resource .*/ $output){}
