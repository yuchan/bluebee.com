<?php

	/*. require_module 'spl'; .*/

	class Test implements Traversable {
	}

