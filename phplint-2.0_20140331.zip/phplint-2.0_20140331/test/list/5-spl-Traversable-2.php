<?php

	/*. require_module 'spl'; .*/

	interface Test1 extends Traversable {
	}

	class Test2 implements Test1 {
	}

