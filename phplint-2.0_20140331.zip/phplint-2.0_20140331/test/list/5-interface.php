<?php

# interface cannot be final|abstract:
final interface if1 {}
abstract interface if2 {}

?>
