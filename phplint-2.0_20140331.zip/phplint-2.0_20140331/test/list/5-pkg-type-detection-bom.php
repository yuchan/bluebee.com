﻿<?php  # <-- Invisible BOM "\xEF\xBB\xBF" here.

?>
